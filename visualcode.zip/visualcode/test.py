import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 
import datetime

# --- Ανάγνωση και προεπεξεργασία δεδομένων ---

csv_file = "2022_2025.csv"
# Χρήση low_memory=False για αποφυγή προειδοποιήσεων
df = pd.read_csv(csv_file, sep=',', encoding='utf-8', header=0, low_memory=False)

print("Available columns:", df.columns.tolist())

# Μετονομασία στηλών ώστε να ταιριάζουν με τα ονόματα που χρησιμοποιούμε στον κώδικα
columns_map = {
    'Timestamp[s]': 'Unix_time',
    'Temp_Out[degC]': 'Temperature',
    'THWS_Index[degC]': 'Feels_Like',
    'Wind_Speed[m/s]': 'Wind_Speed'
}
df.rename(columns=columns_map, inplace=True)

# Μετατροπή βασικών στηλών σε αριθμητικούς τύπους
cols_to_convert = ['Unix_time', 'Temperature', 'Feels_Like', 'Wind_Speed']
for col in cols_to_convert:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Αφαίρεση γραμμών με NaN στις βασικές στήλες
df = df.dropna(subset=cols_to_convert)

# Δημιουργία στήλης ημερομηνίας (χρησιμοποιούμε τις στήλες Year, Month, Day, Hour, Minute)
df['Date'] = pd.to_datetime(df[['Year', 'Month', 'Day', 'Hour', 'Minute']])

# Δημιουργία στήλης για Year-Month (περίοδο)
df['YearMonth'] = df['Date'].dt.to_period('M')

# --- Ορισμός συνάρτησης για μέσο όρο χωρίς outlier χρησιμοποιώντας IQR ---

def mean_without_outliers(x):
    q1 = x.quantile(0.25)
    q3 = x.quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    filtered = x[(x >= lower_bound) & (x <= upper_bound)]
    return filtered.mean()

# Ομαδοποίηση ανά μήνα και υπολογισμός των μέσων όρων για Temperature και Feels_Like
monthly = df.groupby('YearMonth').agg({
    'Temperature': mean_without_outliers,
    'Feels_Like': mean_without_outliers
}).reset_index()

# Μετατροπή της περιόδου σε Timestamp για χρήση στον x-άξονα
monthly['Date'] = monthly['YearMonth'].dt.to_timestamp()

# --- Σχεδίαση γραφήματος με ομαδοποιημένα δεδομένα ανά μήνα ---

fig, ax = plt.subplots(figsize=(12,6))
ax.plot(monthly['Date'], monthly['Temperature'], marker='o', label='Temperature')
ax.plot(monthly['Date'], monthly['Feels_Like'], marker='o', label='Feels-like')

ax.set_title('Μηνιαίοι Μέσοι Όροι Θερμοκρασίας (χωρίς outliers)')
ax.set_xlabel("Ημερομηνία")
ax.set_ylabel("Θερμοκρασία (°C)")
ax.legend()

# Προσθήκη κάθετων γραμμών στα όρια των ετών και επισήμανση μηνών
unique_years = monthly['Date'].dt.year.unique()

# Για κάθε έτος, βρίσκουμε την αρχή και το τέλος του και προσθέτουμε γραμμές
for year in unique_years:
    subset = monthly[monthly['Date'].dt.year == year]
    if subset.empty:
        continue
    start_date = subset['Date'].min()
    end_date = subset['Date'].max()
    ax.axvline(x=start_date, color='gray', linestyle='--', linewidth=0.7)
    ax.axvline(x=end_date, color='gray', linestyle='--', linewidth=0.7)
    
    # Επισήμανση μηνών μέσα στο διάστημα του έτους
    # Λαμβάνουμε το όριο του y-άξονα για να τοποθετήσουμε τα κείμενα
    y_min, y_max = ax.get_ylim()
    for _, row in subset.iterrows():
        month_str = row['Date'].strftime('%b')
        # Τοποθέτηση του κειμένου λίγο πάνω από το κάτω όριο
        ax.text(row['Date'], y_min + (y_max - y_min)*0.05, month_str, 
                rotation=90, fontsize=8, verticalalignment='bottom', horizontalalignment='center')

plt.tight_layout()
plt.show()
fig.savefig("monthly_averages.png")
