import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import StringIO
import requests 
import earthkit 
import cdsapi
import cfgrib
import pandas as pd

df = pd.read_csv('2022_2025.csv')  
print(df.head()) 
