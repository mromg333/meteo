import xarray as xr


ds = xr.open_dataset("download.grib", engine="cfgrib")


print(ds)
import os

file_path = r"C:\Users\xatdi\Desktop\visualcode"


if os.path.exists(file_path):
    print("File exists!")
else:
    print("File NOT found!")

import cdsapi

c = cdsapi.Client()

c.retrieve(
    "reanalysis-era5-single-levels",
    {
        "variable": "2m_temperature",
        "product_type": "reanalysis",
        "year": "2024",
        "month": "01",
        "day": "01",
        "time": "12:00",
        "format": "netcdf"
    },
    "test.nc"
)
