import os
print(os.path.exists("C:\\Users\\xatdi\\.cdsapirc"))
import cdsapi

client = cdsapi.Client()
print("CDS API connection successful!")
