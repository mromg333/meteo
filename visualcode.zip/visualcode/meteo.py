import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px

from statsmodels.tsa.seasonal import seasonal_decompose
import matplotlib.image as mpimg

# ==========================
# 0. Ανάγνωση και Προεπεξεργασία Δεδομένων
# ==========================
csv_file = "2022_2025.csv"
df = pd.read_csv(csv_file, sep=',', encoding='utf-8', header=0, low_memory=False)


#print("Available columns:", df.columns.tolist())  # Εμφάνιση διαθέσιμων στηλών για επιβεβαίωση

# Μετονομασία βασικών στηλών ώστε να είναι συνεπείς με τον κώδικα
columns_map = {
    'Timestamp[s]': 'Unix_time',
    'Temp_Out[degC]': 'Temperature',
    'THWS_Index[degC]': 'Feels_Like',
    'Wind_Speed[m/s]': 'Wind_Speed'
}
df.rename(columns=columns_map, inplace=True)

# Μετατροπή στηλών σε αριθμητικούς τύπους και αφαίρεση γραμμών με NaN
cols_to_convert = ['Unix_time', 'Temperature', 'Feels_Like', 'Wind_Speed']
for col in cols_to_convert:
    df[col] = pd.to_numeric(df[col], errors='coerce')
df = df.dropna(subset=cols_to_convert)

# Δημιουργία στήλης Date από τις στήλες Year, Month, Day, Hour, Minute
df['Date'] = pd.to_datetime(df[['Year', 'Month', 'Day', 'Hour', 'Minute']])
df.sort_values('Date', inplace=True)
df.reset_index(drop=True, inplace=True)

# ==========================
# 1. Ομαδοποίηση ανά Εβδομάδα και Υπολογισμός Score
# ==========================
# Δημιουργία στήλης 'Week' με την ημερομηνία έναρξης της εβδομάδας
df['Week'] = df['Date'].dt.to_period('W').dt.start_time

# Ομαδοποίηση ανά εβδομάδα και υπολογισμός μέσης θερμοκρασίας και μέσου ανέμου
weekly = df.groupby('Week').agg({
    'Temperature': 'mean',
    'Wind_Speed': 'mean'
}).reset_index()

# Προσθήκη στήλης για τον μήνα (ως string) ώστε να ομαδοποιήσουμε ανά μήνα
weekly['Month'] = weekly['Week'].dt.to_period('M').astype(str)

# Ορισμός του ιδανικού επιπέδου θερμοκρασίας
ideal_temp = 20

# Υπολογισμός score βάσει του τύπου: |Temperature - 20| + Wind_Speed
weekly['Score'] = abs(weekly['Temperature'] - ideal_temp) + weekly['Wind_Speed']

# ==========================
# 2. Εύρεση Καλύτερης Εβδομάδας ανά Μήνα
# ==========================
def best_week_temp(group):
    group = group.copy()
    group['Temp_Diff'] = abs(group['Temperature'] - ideal_temp)
    best = group.loc[group['Temp_Diff'].idxmin()]
    return best

best_week_by_month = weekly.groupby('Month', group_keys=False).apply(best_week_temp).reset_index(drop=True)

#tried but didnt work to fix the error 

#best_week_by_month = weekly.groupby('Month', group_keys=False).apply(best_week_temp).reset_index(drop=True)
#best_week_by_month = weekly.groupby('Month')[['Week', 'Temperature', 'Wind_Speed', 'Score']].apply(best_week_temp).reset_index(drop=True)

#best_week_by_month = weekly.groupby('Month', group_keys=True).apply(best_week_temp).reset_index(drop=True)
#best_week_by_month['Month'] = best_week_by_month['Week'].dt.to_period('M').astype(str)

# Προσθήκη στήλης hover text με πληροφορίες για την εβδομάδα
weekly['Hover_Info'] = "Εβδομάδα: " + weekly['Week'].astype(str) + \
                       "<br>Temp: " + weekly['Temperature'].round(1).astype(str) + "°C" + \
                       "<br>Wind: " + weekly['Wind_Speed'].round(1).astype(str) + " m/s" + \
                       "<br>Score: " + weekly['Score'].round(1).astype(str)

best_week_by_month['Hover_Info'] = "Καλύτερη εβδομάδα του μήνα " + best_week_by_month['Month'] + \
                                   "<br>Εβδομάδα: " + best_week_by_month['Week'].astype(str) + \
                                   "<br>Temp: " + best_week_by_month['Temperature'].round(1).astype(str) + "°C" + \
                                   "<br>Wind: " + best_week_by_month['Wind_Speed'].round(1).astype(str) + " m/s" + \
                                   "<br>Score: " + best_week_by_month['Score'].round(1).astype(str)



# ==========================
# 3. Δημιουργία Διαδραστικού Διαγράμματος με Plotly
# ==========================

fig = px.scatter(weekly, x='Week', y='Score',
                 hover_data=['Hover_Info'],
                 title='Καλύτερες Εβδομάδες (Βάσει Θερμοκρασίας και Ανέμου)',
                 labels={'Score': 'Score (|Temp-20| + Wind_Speed)', 'Week': 'Εβδομάδα'},
                 color_discrete_sequence=['gray'])

# Προσθήκη επισημασμένων σημείων για τις καλύτερες εβδομάδες ανά μήνα με σύνδεση γραμμής
fig.add_scatter(x=best_week_by_month['Week'], y=best_week_by_month['Score'],
                mode='lines+markers',
                marker=dict(color='red', size=12, symbol='circle'),
                name='Καλύτερη εβδομάδα ανά μήνα',
                hovertext=best_week_by_month['Hover_Info'],
                hoverinfo='text')

fig.update_layout(hovermode='closest')
fig.show()


'''
fig = px.scatter(weekly, x='Week', y='Score',
                 hover_data=['Hover_Info'],
                 title='Καλύτερες Εβδομάδες (Βάσει Θερμοκρασίας και Ανέμου)',
                 labels={'Score': 'Score (|Temp-20| + Wind_Speed)', 'Week': 'Εβδομάδα'},
                 color_discrete_sequence=['gray'])

fig.add_scatter(x=best_week_by_month['Week'], y=best_week_by_month['Score'],
                mode='lines+markers',
                marker=dict(color='red', size=12, symbol='circle'),
                name='Καλύτερη εβδομάδα ανά μήνα',
                hovertext=best_week_by_month['Hover_Info'],
                hoverinfo='text')

fig.update_layout(hovermode='closest')

fig.write_image("best_weeks.png", width=1200, height=800)

img = mpimg.imread("best_weeks.png")

fig, ax = plt.subplots(figsize=(15, 8))

ax.imshow(img)
ax.axis("off")  # Κρύβουμε τους άξονες

text_x = 1.05  # Ρύθμιση τοποθέτησης κειμένου
text_y = 1.0
line_height = -0.08

ax.text(text_x, text_y, "Καλύτερες Εβδομάδες ανά Μήνα", fontsize=14, fontweight="bold", transform=ax.transAxes)

for i, row in best_week_by_month.iterrows():
    info = f"{row['Week'].date()} - Temp: {row['Temperature']:.1f}°C, Wind: {row['Wind_Speed']:.1f} m/s, Score: {row['Score']:.1f}"
    ax.text(text_x, text_y + (i + 1) * line_height, info, fontsize=12, transform=ax.transAxes)

plt.savefig("best_weeks_final.png", bbox_inches="tight", dpi=300)
plt.show()
'''










# ==========================
# 2. Seasonal Decomposition της Θερμοκρασίας (Μηνιαία)
# ==========================
# Ομαδοποίηση ανά μήνα για τη θερμοκρασία
df['YearMonth'] = df['Date'].dt.to_period('M')
monthly_temp = df.groupby('YearMonth')['Temperature'].mean().reset_index()
monthly_temp['Date'] = monthly_temp['YearMonth'].dt.to_timestamp()

# Εφαρμογή seasonal decomposition σε μηνιαία δεδομένα (period=12 για 12 μήνες)
result = seasonal_decompose(monthly_temp.set_index('Date')['Temperature'], model='additive', period=12)
result.plot()
plt.suptitle('Seasonal Decomposition της Μηνιαίας Θερμοκρασίας', fontsize=14)
plt.tight_layout()
plt.savefig("seasonal_decomposition_temperature.png")
plt.show()

# ==========================
# 3. Seasonal Trends - Εποχικές Τάσεις (Μηνιαία Μέση Θερμοκρασία)
# ==========================
plt.figure(figsize=(12,6))
plt.plot(monthly_temp['Date'], monthly_temp['Temperature'], marker='o', color='darkblue')
plt.title('Μηνιαίες Μέσες Τιμές Θερμοκρασίας (Εποχικές Τάσεις)')
plt.xlabel('Ημερομηνία')
plt.ylabel('Θερμοκρασία (°C)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("seasonal_trends_temperature.png")
plt.show()

# ==========================
# 4. Προγνωστικές Αναλύσεις Growing Degree Days (GDD)
# ==========================
# Ο υπολογισμός των GDD: GDD = (Temperature - T_base), όπου T_base ορίζεται (π.χ. 10°C)
T_base = 10
df['GDD'] = df['Temperature'].apply(lambda temp: temp - T_base if temp > T_base else 0)

# Συσσώρευση GDD ανά μήνα
monthly_GDD = df.groupby('YearMonth')['GDD'].sum().reset_index()
monthly_GDD['Date'] = monthly_GDD['YearMonth'].dt.to_timestamp()

plt.figure(figsize=(12,6))
plt.bar(monthly_GDD['Date'], monthly_GDD['GDD'], width=20, color='orange')
plt.title('Μηνιαία Συσσώρευση Growing Degree Days (GDD)')
plt.xlabel('Ημερομηνία')
plt.ylabel('Συσσώρευση GDD')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("monthly_GDD.png")
plt.show()