import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Φόρτωση δεδομένων
csv_file = "2022_2025.csv"
df = pd.read_csv(csv_file, sep=',', encoding='utf-8', header=0, low_memory=False)

# Μετονομασία βασικών στηλών ώστε να είναι συνεπείς με τον κώδικα
columns_map = {
    'Timestamp[s]': 'Unix_time',
    'Temp_Out[degC]': 'Temperature',
    'THWS_Index[degC]': 'Feels_Like',
    'Wind_Speed[m/s]': 'Wind_Speed'
}
df.rename(columns=columns_map, inplace=True)

# Μετατροπή στηλών σε αριθμητικούς τύπους και αφαίρεση γραμμών με NaN
cols_to_convert = ['Unix_time', 'Temperature', 'Feels_Like', 'Wind_Speed']
for col in cols_to_convert:
    df[col] = pd.to_numeric(df[col], errors='coerce')
df = df.dropna(subset=cols_to_convert)

# Δημιουργία στήλης Date από τις στήλες Year, Month, Day, Hour, Minute
df['Date'] = pd.to_datetime(df[['Year', 'Month', 'Day', 'Hour', 'Minute']])
df.sort_values('Date', inplace=True)
df.reset_index(drop=True, inplace=True)

# Μετατροπή στήλης Rain[mm] και Hum_Out[%] σε αριθμητικά δεδομένα
df['Rain[mm]'] = pd.to_numeric(df['Rain[mm]'], errors='coerce')
df['Hum_Out[%]'] = pd.to_numeric(df['Hum_Out[%]'], errors='coerce')

# Αφαίρεση γραμμών με NaN για Rain[mm] και Hum_Out[%]
df = df.dropna(subset=['Rain[mm]', 'Hum_Out[%]'])



# Υπολογισμός υγρασίας εδάφους
def calculate_soil_moisture(df):
    soil_moisture = np.full(len(df), 30.0)
    increase_factor = 5
    decrease_factor = 0.95
    temp_factor = 0.1
    wind_factor = 0.05
    hum_factor = 0.02

    for i in range(1, len(df)):
        # Εξασφαλίζουμε ότι οι τιμές για Rain[mm] και Hum_Out[%] είναι αριθμητικές
        rain_value = pd.to_numeric(df.at[i-1, "Rain[mm]"], errors='coerce')
        hum_value = pd.to_numeric(df.at[i-1, "Hum_Out[%]"], errors='coerce')
        
        rain_effect = min(100, soil_moisture[i-1] + rain_value * increase_factor)
        temp_effect = df.at[i-1, "Temperature"] * temp_factor
        wind_effect = df.at[i-1, "Wind_Speed"] * wind_factor
        hum_effect = hum_value * hum_factor
        decay_effect = max(0, soil_moisture[i-1] * (decrease_factor - temp_effect - wind_effect + hum_effect))       
        # Περιορισμός για αποφυγή overflow
        soil_moisture[i] = min(100, rain_effect if df.at[i, "Rain[mm]"] > 0 else decay_effect)
         
    df["Soil_Moisture"] = soil_moisture
    return df

# Προσθήκη συνθηκών για σπορά και ψεκασμό
def determine_sowing_spraying_periods(df):
    df['Sowing_Condition'] = np.where(
        (df['Soil_Moisture'] >= 30) & 
        (df['Soil_Moisture'] <= 70) & 
        (df['Temperature'] >= 10) & 
        (df['Temperature'] <= 25) & 
        (df['Hum_Out[%]'] > 30),
        'Κατάλληλο', 'Ακατάλληλο'
    )

#df spraying works with | (OR) , Probably issue with the values (check further)
    df['Spraying_Condition'] = np.where(
        (df['Soil_Moisture'] < 60) & 
        (df['Wind_Speed'] < 5) & 
        (df['Hum_Out[%]'] > 40),
        'Κατάλληλο', 'Ακατάλληλο'
    )
    
    return df

def find_best_periods(df):
    df['Month'] = df['Date'].dt.month
    # Εξασφάλιση ότι η Soil_Moisture είναι αριθμητική
    df["Soil_Moisture"] = pd.to_numeric(df["Soil_Moisture"], errors='coerce')
    
    best_sowing = df[df['Sowing_Condition'] == 'Κατάλληλο'].groupby('Month')['Soil_Moisture'].median()
    best_spraying = df[df['Spraying_Condition'] == 'Κατάλληλο'].groupby('Month')['Soil_Moisture'].median()
    return best_sowing, best_spraying

def display_summary_table(df):
    # Δημιουργούμε έναν συνοπτικό πίνακα με μέσες τιμές για κάθε μήνα
    df['Month'] = df['Date'].dt.month
    summary = df.groupby('Month').agg({
        'Soil_Moisture': 'median',
        'Temperature': 'median',
        'Hum_Out[%]': 'median',
        'Rain[mm]': 'median'
    }).reset_index()
    summary.columns = ['MONTH', 'MEDIUM MOIST', 'MEDIUM TEMP', 'MEDIUM AIR TEMP', 'MEDIUM RAIN']
    print("Summary:")
    print(summary)
    return summary

def plot_best_periods(df):
    best_sowing, best_spraying = find_best_periods(df)
    
    # Συνδυασμένο γράφημα bar για καλύτερες περιόδους
    months = range(1, 13)
    sowing_values = [best_sowing.get(m, np.nan) for m in months]
    spraying_values = [best_spraying.get(m, np.nan) for m in months]
    
    x = np.arange(len(months))
    width = 0.35

    fig, ax = plt.subplots(figsize=(12, 6))
    bars1 = ax.bar(x - width/2, sowing_values, width, label='Σπορά', color='green')
    bars2 = ax.bar(x + width/2, spraying_values, width, label='Ψεκασμός', color='blue')

    ax.set_xlabel('Μήνας')
    ax.set_ylabel('Μέση Υγρασία Εδάφους (%)')
    ax.set_title('Κατάλληλες Περιόδοι για Σπορά και Ψεκασμό')
    ax.set_xticks(x)
    ax.set_xticklabels(months)
    ax.legend()
    ax.grid(True, axis='y', linestyle='--', alpha=0.7)
    
    # Προσθέτουμε τιμές πάνω από τα bars για διευκόλυνση
    for bar in bars1 + bars2:
        height = bar.get_height()
        if not np.isnan(height):
            ax.annotate(f'{height:.1f}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),  # offset
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=9)



    plt.show()

# Εκτέλεση υπολογισμών
df = calculate_soil_moisture(df)
df = determine_sowing_spraying_periods(df)

# Εμφάνιση συνοπτικού πίνακα στο terminal/console
summary_table = display_summary_table(df)

plot_best_periods(df)



# Φιλτράρουμε θερμοκρασίες μεταξύ 0°C και 7.2°C για Chilling Hours
df['Chilling_Hours'] = df['Temperature'].apply(lambda x: 1 if 0 <= x <= 7.2 else 0)

# Ομαδοποίηση ανά μήνα
chilling_hours_monthly = df.groupby(df['Date'].dt.month)['Chilling_Hours'].sum()

# Σχεδίαση διαγράμματος
plt.figure(figsize=(10, 5))
plt.bar(chilling_hours_monthly.index, chilling_hours_monthly.values, color='blue')
plt.xlabel("Μήνας")
plt.ylabel("Συνολικές Ώρες Ψύχους")
plt.title("Chilling Hours Ανά Μήνα")
plt.xticks(range(1, 13), ["Ιαν", "Φεβ", "Μαρ", "Απρ", "Μαϊ", "Ιουν", "Ιουλ", "Αυγ", "Σεπ", "Οκτ", "Νοε", "Δεκ"])
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.savefig("chilling.png")
plt.show()
